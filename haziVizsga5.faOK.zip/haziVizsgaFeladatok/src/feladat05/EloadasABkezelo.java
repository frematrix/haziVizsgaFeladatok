package feladat05;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class EloadasABkezelo {
	
	private static Connection kapcsolat;
	private static PreparedStatement utasitas;
	
	public static void kapcsolat() throws SQLException  {
		
		
		try {
			String cim = "jdbc:mysql://localhost:3306/szinhaz_eloadasok_db?useSSL=false";
			kapcsolat = (Connection) DriverManager.getConnection(cim, "root", "Vagyok1125");
		} catch (Exception e) {
			throw new SQLException("Kapcsolat sikertelen");
		
		}
		
	}

	public static List<Eloadas> beolvasas() throws SQLException {
		
		
		try {
			List<Eloadas> eloadasok = new ArrayList<Eloadas>();
			utasitas = kapcsolat.prepareStatement("SELECT * from eloadasok");
			ResultSet result = utasitas.executeQuery();
			
			while (result.next()) {
				//cim, rendezo, bemutato, eloadas_szam
				eloadasok.add(new Eloadas(result.getString("cim"), result.getString("rendezo"), 
						result.getDate("bemutato").toLocalDate(), result.getInt("eloadas_szam")));
			}
			
			result.close();
			return eloadasok;
			
		} catch (Exception e) {
			throw new SQLException("Beolvasás sikertelen");
		}
		
		
	}

	public static void torles(Eloadas eloadas) throws SQLException {
		
		try {
			utasitas = kapcsolat.prepareStatement("DELETE from eloadasok WHERE cim=?");
			utasitas.setString(1, eloadas.getEloadasCime());
			utasitas.executeUpdate();
			utasitas.clearParameters();
			
		} catch (Exception e) {
			throw new SQLException("Törlés sikertelen!");
		}
		
	}
	
	

}
