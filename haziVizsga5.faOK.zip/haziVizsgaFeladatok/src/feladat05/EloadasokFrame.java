package feladat05;

import java.sql.SQLException;
import java.util.List;

import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JList;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class EloadasokFrame {

	private JFrame frmEloadasok;
	private List<Eloadas> eloadasok;
	private DefaultListModel<Eloadas> model;
	private JList listaMegjelenit;

	public JFrame getFrmEloadasok() {
		return frmEloadasok;
	}

	
	public EloadasokFrame()  {
		initialize();
		try {
			EloadasABkezelo.kapcsolat();
			eloadasok = EloadasABkezelo.beolvasas();
			adatmegjelenites();
			
			
			
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(frmEloadasok, e.getMessage(), "Hiba!", JOptionPane.ERROR_MESSAGE);
		}
		
	}


	private void adatmegjelenites() {
		
		model = new DefaultListModel<Eloadas>();
		
		for (Eloadas eloadas : eloadasok) {
			
			model.addElement(eloadas);
			
		}
		listaMegjelenit.setModel(model);
	}


	private void initialize() {
		
		frmEloadasok = new JFrame();
		frmEloadasok.setTitle("Színházi előadások");
		frmEloadasok.setBounds(100, 100, 700, 400);
		frmEloadasok.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmEloadasok.getContentPane().setLayout(null);
		
		listaMegjelenit = new JList();
		listaMegjelenit.setBounds(26, 35, 633, 226);
		frmEloadasok.getContentPane().add(listaMegjelenit);
		
		JButton btnTorles = new JButton("Törlés");
		btnTorles.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				torles();
			}
		});
		btnTorles.setBounds(26, 280, 89, 23);
		frmEloadasok.getContentPane().add(btnTorles);
		
		
		
	}


	protected void torles() {
		
		if (listaMegjelenit.getSelectedIndex()!=-1 && JOptionPane.showOptionDialog(frmEloadasok, 
				"Biztos törli?", "Adattörlés", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, 
				null, null, null)==JOptionPane.YES_OPTION) {
			
			try {
				EloadasABkezelo.torles(eloadasok.get(listaMegjelenit.getSelectedIndex()));
			} catch (SQLException e) {
				
				JOptionPane.showMessageDialog(frmEloadasok, e.getMessage(), "Hiba", JOptionPane.ERROR_MESSAGE);
			}
			eloadasok.remove(listaMegjelenit.getSelectedValue());
			model.remove(listaMegjelenit.getSelectedIndex());
			
		}
		
	}
}
