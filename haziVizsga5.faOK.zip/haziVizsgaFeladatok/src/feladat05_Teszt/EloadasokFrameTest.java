package feladat05_Teszt;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.DriverManager;
import java.sql.SQLException;

import org.junit.jupiter.api.Test;

import feladat05.EloadasokFrame;

class EloadasokFrameTest {

	@Test
	void initializeTeszt() {
		
		EloadasokFrame foAblak = new EloadasokFrame();
		
		// szélesség 700 ellenőrzése:
		assertTrue(foAblak.getFrmEloadasok().getBounds().width == 700);

	}
	
	@Test
	void csatlakozasTeszt() {
		
		String hibasURL = "jdbc:mysql://localhost:3306/szinhaz_eloadashibas_db?autoReconnect=true&useSSL=false";
		
		assertThrows(SQLException.class, () -> DriverManager.getConnection(hibasURL,"root","Vagyok1125") );
	}

}
